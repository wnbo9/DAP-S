#' DAP-S fine-mapping with individual-level data.
#' The parameters are directly obtained from SuSiE results.
#' @param X Genotype data
#' @param y Phenotype data
#' @param L Number of causal variants
#' @param scaled_prior_variance Scaled prior effect size variance. The prior
#' variance, divided by \code{var(y)}; that is, the prior variance of each
#' non-zero element of b is \code{var(y) * scaled_prior_variance}.
#' So it is equal to phi^2 in the BVSR with D2 prior.
#' @param residual_variance Residual variance.
#' If \code{estimate_residual_variance = TRUE}, this value provides the
#' initial estimate of the residual variance.
#' @param prior_weights Prior weights
#' @param null_weight Null weight. Probability of no effects,
#' it should be between 0 and 1.
#' @param estimate_residual_variance
#' If \code{estimate_residual_variance = TRUE}, the residual variance is
#' estimated, using \code{residual_variance} as an initial value.
#' If \code{estimate_residual_variance = FALSE}, the residual variance
#' is fixed to the value supplied by \code{residual_variance}.
#' @param estimate_prior_variance If \code{estimate_prior_variance = TRUE},
#' the prior variance is estimated (this is a separate parameter for each
#' of the L effects). If provided, \code{scaled_prior_variance} is then used
#' as an initial value for the optimization.
#' When \code{estimate_prior_variance = FALSE}, the prior variance for each of
#' the L effects is determined by the value supplied to
#' \code{scaled_prior_variance}.
#' @param r2_threshold Genotype R2 threshold for LD
#' @param coverage Coverage of credible sets. When not set, it outputs signal
#' clusters; otherwise, it outputs credible sets at the specified
#' coverage level.
#' @param use_susie_variance_estimate
#' If \code{use_susie_variance_estimate = TRUE},the SuSiE variance estimate (V)
#' is used to compute the Bayes factor.
#' If \code{use_susie_variance_estimate = FALSE}, the Bayes factor is calculated
#' by averaging over a grid of values provided in \code{phi2_vec}.
#' @param phi2_vec Scaled prior effect size variance vector.
#' If \code{use_susie_variance_estimate = FALSE}, this vector is used
#' to compute the Bayes factor.
#' @param greedy If \code{greedy = TRUE}, the greedy algorithm is used
#' to find the best model, instead of conducting Pseudo-Importance Resampling.
#' @param pir_threshold Threshold for PIR when \code{greedy = FALSE}.
#' @import Rfast
#' @importFrom susieR susie
#' @importFrom dplyr %>% arrange desc
#' @return Fine mapping results
#'
#' @export
dap_susie <- function(X, y, L = min(10, ncol(X)),
                scaled_prior_variance = 0.2,
                residual_variance = NULL,
                prior_weights = NULL,
                null_weight = NULL,
                estimate_residual_variance = TRUE,
                estimate_prior_variance = TRUE,
                r2_threshold = 0.25,
                coverage = NULL,
                use_susie_variance_estimate = FALSE,
                phi2_vec = c(0.04, 0.16, 0.64),
                greedy = FALSE,
                pir_threshold = 1e-6) {

  # Process inputs
  cat("Processing inputs...\n")
  X <- scale(X, scale = FALSE)
  y <- scale(y, scale = FALSE)
  p <- ncol(X)
  if (is.null(colnames(X))) colnames(X) <- paste0("SNP_", 1:p)

  ## Initialize parameters
  cat("Initializing parameters...\n")
  if (is.null(null_weight)) null_weight <- (1 - 1 / p)^p
  if (is.null(prior_weights)) prior_weights <- rep(1 / p, p)
  if (is.null(coverage)) coverage <- 2

  # Run SuSiE
  cat("Running SuSiE...\n")
  susie_fit <- susie(X, y, L, max_iter = 1000, coverage = 0.95,
                     scaled_prior_variance = scaled_prior_variance,
                     residual_variance = residual_variance,
                     null_weight = null_weight, prior_weights = prior_weights,
                     estimate_residual_variance = estimate_residual_variance,
                     estimate_prior_variance = estimate_prior_variance)
  # Extract matrix of sampling density from SuSiE results
  mat <- get_mat(susie_fit)

  cat("Running DAP-S fine-mapping...\n")
  # then we do PIR (or greedy) to get models
  results <- dap_susie_main(X, y, mat,
                            prior_weights, r2_threshold, coverage,
                            use_susie_variance_estimate, phi2_vec,
                            greedy, pir_threshold)

  # summarize results
  cat("Summarizing results...\n")
  output <- get_summarization(results, mat,
                              pir_threshold, r2_threshold,
                              scaled_prior_variance, phi2_vec,
                              prior_weights, null_weight, colnames(X))

  # Return results
  cat("Done!\n")
  return(output)
}