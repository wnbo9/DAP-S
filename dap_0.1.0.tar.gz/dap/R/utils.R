#' Process matrix to keep only columns where the SNP ranks highest.
#' @param mat Input matrix
#' @import Rfast
#' @return Matrix with only first maximum value kept in each row
#' @noRd
process_matrix <- function(mat) {
  ranks <- Rfast::colRanks(mat, descending = TRUE)
  # returns matrix with ranks by columns
  mask <- ranks == Rfast::rowMins(ranks, value = TRUE)
  mask <- col(mask) == apply(mask, 1, which.max)
  return(mat * mask)
}

#' Extract matrix from SuSiE fit
#' @param susie_fit SuSiE fit
#' @return Matrix of sampling
#' @noRd
get_mat <- function(susie_fit) {
  matrix <- t(susie_fit$alpha)
  # We only keep at most one column with null as top among all non-zero effects.
  # Note SuSiE can output two columns with similar ranks, we keep the first.
  mat <- as.matrix(matrix[, 1:sum(susie_fit$V != 0)])
  max_indices <- apply(mat, 2, which.max)
  # Keep first occurrence of each maximum position
  keep_cols <- !duplicated(max_indices)
  mat <- mat[, keep_cols, drop = FALSE]
  # we need to pre-process the mat,so that each SNP only appears in the effect
  # where it has highest rank.
  mat <- process_matrix(mat)
  return(mat)
}


#' Get summarization of fine mapping results
#' @param results Fine mapping results
#' @param mat Matrix of sampling density
#' @param pir_threshold Threshold for PIR
#' @param r2_threshold Threshold for R2
#' @param scaled_prior_variance Scaled prior variance
#' @param phi2_vec Vector of prior variances
#' @param prior_weights Prior weights
#' @param null_weight Null weight
#' @param snp_names SNP names
#' @return Summarized results
#' @noRd
get_summarization <- function(results, mat,
                              pir_threshold, r2_threshold,
                              scaled_prior_variance, phi2_vec,
                              prior_weights, null_weight, snp_names) {
  # Create model results dataframe
  result_df <- data.frame(
    Model = results$model_config,
    Posterior_Prob = results$posterior_prob,
    Log10_Posterior_Score = results$log10_posterior_score, 
    Log10_BF = results$log10_BF,
    Log10_Prior = results$log10_prior,
    stringsAsFactors = FALSE
  ) %>%
    arrange(desc(Log10_Posterior_Score))

  # Store parameters
  params <- list(
    log10_nc = results$log10_nc,
    pir_threshold = pir_threshold,
    r2_threshold = r2_threshold,
    phi2 = scaled_prior_variance,
    phi2_vec = phi2_vec,
    prior_weights = prior_weights,
    null_weight = null_weight
  )

  # Initialize SNP dataframe
  snp <- data.frame(
    SNP = snp_names,
    PIP = results$pip,
    cluster_index = -1,
    in_cluster_order = Inf,
    stringsAsFactors = FALSE
  )

  # Process signal clusters if they exist
  if (!is.null(results$signal_cluster)) {
    for (i in seq_along(results$signal_cluster$clusters)) {
      for (order in seq_along(results$signal_cluster$clusters[[i]])) {
        snp_name <- results$signal_cluster$clusters[[i]][order]
        idx <- which(snp$SNP == snp_name)

        if (snp$cluster_index[idx] != -1) {
          # Reassign only if new order is better
          if (order < snp$in_cluster_order[idx]) {
            message(sprintf(
              "SNP %s reassigned from cluster %d to cluster %d (order improved from %d to %d)",
              snp_name, snp$cluster_index[idx], i,
              snp$in_cluster_order[idx], order
            ))
            snp$cluster_index[idx] <- i
            snp$in_cluster_order[idx] <- order
          }
        } else {
          # First assignment
          snp$cluster_index[idx] <- i
          snp$in_cluster_order[idx] <- order
        }
      }
    }
  }

  # Return compiled results
  list(
    alpha = mat,
    variants = snp %>% arrange(desc(PIP)),
    models = result_df,
    sets = results$signal_cluster,
    elements = results$element_cluster,
    params = params
  )
}